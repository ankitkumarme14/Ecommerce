package com.orderService.controller;

import com.orderService.payload.OrderDto;
import com.orderService.service.OrderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class OrderController {
    private OrderService orderService;

    public OrderController(OrderService orderService){
        this.orderService=orderService;
    }

    // create order
    @PostMapping("/order")
    public ResponseEntity<OrderDto> createOrder(@RequestBody OrderDto orderDto){
        OrderDto createdOrder = orderService.createOrder(orderDto);
        return new ResponseEntity<>(orderDto, HttpStatus.CREATED);
    }

    // delete order
    @DeleteMapping("/order/{orderId}")
    public ResponseEntity<String> deleteOrder(@PathVariable Long orderId){
        orderService.deleteByOrderId(orderId);
        return new ResponseEntity<>("Order is Deleted successfully.", HttpStatus.OK);
    }


}
