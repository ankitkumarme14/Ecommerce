package com.orderService.service;

import com.orderService.payload.OrderDto;

public interface OrderService {

    OrderDto createOrder( OrderDto orderDtO);

    void deleteByOrderId(Long orderId);
}
