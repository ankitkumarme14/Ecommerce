package com.orderService.payload;

import com.orderService.entity.Product;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class OrderDto {
    private Long orderId;
    private Long userId;
    private double totalPrice;
    private List<Product> productList= new ArrayList<>();
}
