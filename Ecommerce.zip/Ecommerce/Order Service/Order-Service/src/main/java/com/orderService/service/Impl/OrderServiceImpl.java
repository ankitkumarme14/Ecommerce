package com.orderService.service.Impl;

import com.orderService.entity.Order;
import com.orderService.exception.ResourceNotFoundException;
import com.orderService.payload.OrderDto;
import com.orderService.repository.OrderRepository;
import com.orderService.service.OrderService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {
    private OrderRepository orderRepository;
    private ModelMapper modelMapper;

    public OrderServiceImpl(OrderRepository orderRepository, ModelMapper modelMapper){
        this.orderRepository=orderRepository;
        this.modelMapper=modelMapper;
    }
    @Override
    public OrderDto createOrder(OrderDto orderDto) {
            Order order = mapToEntity(orderDto);
            Order saved = orderRepository.save(order);
            OrderDto dto = mapToDto(saved);
            return dto;
    }

    @Override
    public void deleteByOrderId(Long orderId) {
        Optional<Order> byId = orderRepository.findById(orderId);

        if(byId.isPresent()){
           orderRepository.deleteById(orderId);
        }else {
            throw new ResourceNotFoundException("Order is not exist for this "+orderId);
        }
    }


    public OrderDto mapToDto(Order order){
        OrderDto dto = modelMapper.map(order, OrderDto.class);
        return dto;
    }

    public Order mapToEntity(OrderDto orderDto){
        Order order = modelMapper.map(orderDto, Order.class);
        return order;
    }


}
