package com.userService.service;

import com.userService.entity.User;
import com.userService.exception.ResourceNotFoundException;
import com.userService.payload.UserDto;
import com.userService.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{

    private UserRepository userRepository;

    private ModelMapper modelMapper;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper){
        this.userRepository=userRepository;
        this.modelMapper=modelMapper;
    }

    @Override
    public UserDto createOneUser(UserDto userDto) {
        User user = mapToEntity(userDto);
        User saved = userRepository.save(user);
        UserDto userDto1 = mapToDto(saved);
        return userDto1;
    }

    @Override
    public UserDto updateUser(Long userId, UserDto userDto) {
        Optional<User> byId = userRepository.findById(userId);
        if(byId.isPresent()){
            User user = mapToEntity(userDto);
            User saved = userRepository.save(user);
            UserDto userDto1 = mapToDto(saved);
            return  userDto1;
        }else {
            throw new ResourceNotFoundException("User is not exist..");
        }

    }

    @Override
    public void deleteUser(Long userId) {
        Optional<User> byId = userRepository.findById(userId);

        if(byId.isPresent()){
           userRepository.deleteById(userId);
        }else {
            throw new ResourceNotFoundException("User is not Exist id:"+userId);
        }
    }


    public UserDto mapToDto(User user){
        UserDto userDto = modelMapper.map(user, UserDto.class);
        return  userDto;
    }

    public User mapToEntity(UserDto userDto){
        User user = modelMapper.map(userDto, User.class);
        return user;
    }

}
