package com.userService.controller;

import com.userService.payload.UserDto;
import com.userService.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class UserController {

    private UserService userService;

    public UserController(UserService userService){
        this.userService=userService;
    }

    // create
    @PostMapping("/user")
    public ResponseEntity<UserDto> createUser(@RequestBody UserDto userDto){
        UserDto oneUser = userService.createOneUser(userDto);
        return new ResponseEntity<>(oneUser, HttpStatus.CREATED);
    }

    // update
    @PutMapping("/user/{userId}")
    public ResponseEntity<UserDto> updateUserById(@PathVariable Long userId, @RequestBody UserDto userDto){
        UserDto userDto1 = userService.updateUser(userId, userDto);
        return new ResponseEntity<>(userDto1, HttpStatus.OK);
    }

    // Delete
    @DeleteMapping("/user/{userId}")
    public ResponseEntity<String> deleteUserById(@PathVariable Long userId){
        userService.deleteUser(userId);
        return new ResponseEntity<>("User is deleted Successfully", HttpStatus.OK);
    }
}
