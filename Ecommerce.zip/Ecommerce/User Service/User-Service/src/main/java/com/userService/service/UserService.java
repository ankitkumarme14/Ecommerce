package com.userService.service;

import com.userService.payload.UserDto;

public interface UserService {

    public UserDto createOneUser(UserDto userDto);
    public UserDto updateUser(Long userId, UserDto userDto);
    public void deleteUser( Long userId);
}
