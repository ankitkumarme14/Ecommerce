package com.userService.entity;

public enum Gender {
    Male, Female

}
