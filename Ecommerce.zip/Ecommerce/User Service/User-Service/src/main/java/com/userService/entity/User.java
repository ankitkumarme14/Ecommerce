package com.userService.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "User")
public class User {
    @Id
    @Column(nullable = false, unique = true)
    private Long userId;
    @Column(nullable = false, unique = false)
    private String name;
    @Column(nullable = false, unique = true)
    private String email;
    @Column(nullable = false, unique = true)
    private String phone;
    @Enumerated(EnumType.STRING)   // for Enum
    private Gender gender;
    @Column(nullable = false, unique = false)
    private String password;

}
