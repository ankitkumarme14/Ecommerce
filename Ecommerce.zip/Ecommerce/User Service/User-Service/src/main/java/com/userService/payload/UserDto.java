package com.userService.payload;

import com.userService.entity.Gender;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class UserDto {
    private Long userId;
    private String name;
    private String email;
    private String phone;
    private Gender gender;
    private String password;
}
